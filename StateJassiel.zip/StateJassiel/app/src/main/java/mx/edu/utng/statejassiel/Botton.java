package mx.edu.utng.statejassiel;

import android.graphics.Canvas;

/**
 * Created by qas on 6/09/16.
 */
public abstract class Botton {
    public abstract void presionarSwitch(Pantalla pant, Canvas canvas);
}
