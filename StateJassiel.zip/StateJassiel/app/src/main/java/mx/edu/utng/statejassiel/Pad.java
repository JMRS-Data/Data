package mx.edu.utng.statejassiel;

import android.content.Context;
import android.graphics.Canvas;
import android.view.View;

/**
 * Created by qas on 6/09/16.
 */
public class Pad extends View{

    private Botton estado;
    private Pantalla tv;

    public Pad(Context context, Botton estado, Pantalla tv){
        super(context);
        this.estado = estado;
        this.tv = tv;
    }

    @Override
    protected void onDraw(Canvas canvas) {
        if(estado!=null&&tv!=null){
            tv.setCanvas(canvas);
            estado.presionarSwitch(tv, canvas);
        }
    }

    public Botton getEstado() {
        return estado;
    }

    public void setEstado(Botton estado) {
        this.estado = estado;
    }
}
