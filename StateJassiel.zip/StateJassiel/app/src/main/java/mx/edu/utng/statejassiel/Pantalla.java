package mx.edu.utng.statejassiel;

import android.graphics.Canvas;

/**
 * Created by qas on 6/09/16.
 */
public class Pantalla {
    private Botton estado;
    private Canvas canvas;

    public Pantalla(Botton estado){
        this.estado = estado;
    }

    public void presionarBoton(){
        estado.presionarSwitch(this, canvas);
    }

    public Canvas getCanvas() {
        return canvas;
    }

    public void setCanvas(Canvas canvas) {
        this.canvas = canvas;
    }

    public Botton getEstado() {
        return estado;
    }

    public void setEstado(Botton estado) {
        this.estado = estado;
    }

}
