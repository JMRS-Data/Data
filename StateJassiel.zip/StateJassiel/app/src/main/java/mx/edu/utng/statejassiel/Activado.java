package mx.edu.utng.statejassiel;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;

/**
 * Created by qas on 6/09/16.
 */
public class Activado extends Botton {
    @Override
    public void presionarSwitch(Pantalla pant, Canvas canvas) {
        pant.setEstado(new Inactivo());
        Paint paint = new Paint();
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(Color.BLUE);
        float mitadX = canvas.getWidth()/2;
        float mitadY = canvas.getHeight()/2;
        canvas.drawRect(mitadX * 50f, mitadY * 50f,
                mitadX * 50f, mitadY * 50f, paint);
        paint.setColor(Color.BLACK);
        canvas.drawRect(mitadX * 0f, mitadY * 0.5f,
                mitadX * 0.6f, mitadY * 1.45f, paint);
    }
}
