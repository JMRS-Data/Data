package mx.edu.utng.factoryaguajassiel;

import android.content.Context;
import android.graphics.Canvas;
import android.view.View;

/**
 * Created by qas on 31/08/16.
 */
public class Lienzo extends View {
    private Dibujar dibujar;

    public Lienzo(Context context, Dibujar dibujar){
        super(context);
        this.dibujar = dibujar;
    }

    @Override
    protected void onDraw(Canvas canvas) {
        if(dibujar !=null){
            dibujar.dibujar(canvas);
        }
    }
    public Dibujar getDibujar() {
        return dibujar;
    }
    public void setDibujar(Dibujar dibujar) {
        this.dibujar = dibujar;
    }
}
