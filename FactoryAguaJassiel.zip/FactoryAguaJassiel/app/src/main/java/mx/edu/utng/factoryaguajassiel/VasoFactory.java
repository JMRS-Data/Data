package mx.edu.utng.factoryaguajassiel;

/**
 * Created by qas on 31/08/16.
 */
public class VasoFactory {

    private Dibujar dibujar;
    public Dibujar crearFigura(String tipo){
        if(tipo!=null){
            if(tipo.equalsIgnoreCase("lleno")){
                dibujar = new Lleno();
            }else if(tipo.equalsIgnoreCase("medio lleno")){
                dibujar = new MLleno();
            }else if(tipo.equalsIgnoreCase("medio vacio")){
                dibujar = new MVacio();
            }else if(tipo.equalsIgnoreCase("vacio")){
                dibujar = new Vacio();
            }
            else {
                return null;
            }
        }
        return dibujar;
    }
}
