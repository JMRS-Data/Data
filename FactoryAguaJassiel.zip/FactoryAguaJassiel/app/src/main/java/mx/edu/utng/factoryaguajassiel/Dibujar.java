package mx.edu.utng.factoryaguajassiel;

import android.graphics.Canvas;

/**
 * Created by qas on 31/08/16.
 */
public interface Dibujar {
    void dibujar(Canvas canvas);
}
