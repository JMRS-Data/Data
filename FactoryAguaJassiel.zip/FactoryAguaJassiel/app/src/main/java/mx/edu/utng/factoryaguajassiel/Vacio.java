package mx.edu.utng.factoryaguajassiel;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;

/**
 * Created by MF on 12/09/2016.
 */
public class Vacio implements Dibujar {
    @Override
    public void dibujar(Canvas canvas) {
        Paint paint = new Paint();
        paint.setStyle(Paint.Style.FILL);
        float mitadX = canvas.getWidth()/2;
        float mitadY = canvas.getHeight()/2;
        paint.setColor(Color.BLUE);
        canvas.drawRect(mitadX*0.4f,mitadY*0.4f,
                mitadX*1.6f,mitadY*2.5f, paint);
        paint.setColor(Color.CYAN);
        canvas.drawRect(mitadX*0.5f,mitadY*1.7f,
                mitadX*1.5f,mitadY*2.0f, paint);

    }
}
