package mx.edu.utng.prototypejassiel2;

/**
 * Created by qas on 2/09/16.
 */
public class Compras implements Clonar {
    private String precio;
    private String producto;

    public Compras(){
        this.precio = "";
        this.producto = "";
    }

    public Compras(String producto, String precio) {
        this.precio = precio;
        this.producto = producto;
    }

    @Override
    public Clonar clonar() {
        Compras comprar = new Compras(precio, producto);
        return comprar;
    }

    public String getPrecio() {
        return precio;
    }

    public void setPrecio(String precio) {
        this.precio = precio;
    }

    public String getProducto() {
        return producto;
    }

    public void setProducto(String producto) {
        this.producto = producto;
    }
}
