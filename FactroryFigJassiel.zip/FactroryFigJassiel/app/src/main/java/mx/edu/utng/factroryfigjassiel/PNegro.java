package mx.edu.utng.factroryfigjassiel;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;

/**
 * Created by MF on 12/09/2016.
 */
public class PNegro implements Figura {
    @Override
    public void dibujar(Canvas canvas) {
        Paint paint = new Paint();
        paint.setStyle(Paint.Style.FILL);
        float mitadX = canvas.getWidth()/2;
        float mitadY = canvas.getHeight()/2;
        paint.setColor(Color.GRAY);
        canvas.drawRect(mitadX*0.2f,mitadY*0.2f,
                mitadX*3.0f,mitadY*3.0f, paint);
        paint.setColor(Color.BLACK);
        canvas.drawRect(mitadX*0.3f,mitadY*0.3f,
                mitadX*3.1f,mitadY*3.1f, paint);
    }
}
