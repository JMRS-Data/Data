package mx.edu.utng.factroryfigjassiel;

import android.content.Context;
import android.graphics.Canvas;
import android.view.View;

/**
 * Created by qas on 31/08/16.
 */
public class Pad extends View {
    private Figura figura;

    public Pad(Context context, Figura figura){
        super(context);
        this.figura = figura;
    }

    @Override
    protected void onDraw(Canvas canvas) {
        if(figura!=null){
            figura.dibujar(canvas);
        }
    }
    public Figura getFigura() {
        return figura;
    }
    public void setFigura(Figura figura) {
        this.figura = figura;
    }
}
