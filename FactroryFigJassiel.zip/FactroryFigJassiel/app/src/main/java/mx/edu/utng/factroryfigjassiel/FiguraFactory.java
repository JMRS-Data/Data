package mx.edu.utng.factroryfigjassiel;

/**
 * Created by qas on 31/08/16.
 */
public class FiguraFactory {

    private Figura figura;
    public Figura crearFigura(String tipo){
        if(tipo!=null){
            if(tipo.equalsIgnoreCase("azul")){
                figura = new PAzul();
            }else if(tipo.equalsIgnoreCase("negro")){
                figura = new PNegro();
            }else if(tipo.equalsIgnoreCase("verde")){
                figura = new PVerde();
            }else if(tipo.equalsIgnoreCase("rojo")){
                figura = new PRojo();
            }
            else {
                return null;
            }
        }
        return figura;
    }
}
