package mx.edu.utng.factroryfigjassiel;

import android.graphics.Canvas;

/**
 * Created by qas on 31/08/16.
 */
public interface Figura {
    void dibujar(Canvas canvas);
}
