package mx.edu.utng.staterjassi2;

import android.content.Context;
import android.graphics.Canvas;
import android.view.View;

/**
 * Created by qas on 19/02/16.
 */
public class Pantalla extends View{
    private BotonCambio estado;
    private Modo modo;

    public Pantalla(Context context, BotonCambio estado, Modo modo) {
        super(context);
        this.estado = estado;
        this.modo = modo;
    }

    @Override
    protected void onDraw(Canvas canvas) {
        if(estado!=null&& modo !=null) {
            modo.setCanvas(canvas);
            estado.oprimirEncendido(modo, canvas);
        }
    }

    public BotonCambio getEstado() {return estado;}

    public void setEstado(BotonCambio estado) {
        this.estado = estado;
    }

}
