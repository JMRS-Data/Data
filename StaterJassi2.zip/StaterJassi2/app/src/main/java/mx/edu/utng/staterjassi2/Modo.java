package mx.edu.utng.staterjassi2;

import android.graphics.Canvas;

/**
 * Created by qas on 5/09/16.
 */
public class Modo {
    private BotonCambio estado;
    private Canvas canvas;

    public Modo(BotonCambio estado){
        this.estado = estado;
    }

    public BotonCambio getEstado() {
        return estado;
    }

    public void setEstado(BotonCambio estado) {
        this.estado = estado;
    }

    public void oprimirBoton(){
        estado.oprimirEncendido(this, canvas);
    }

    public Canvas getCanvas() {
        return canvas;
    }

    public void setCanvas(Canvas canvas) {
        this.canvas = canvas;
    }
}
