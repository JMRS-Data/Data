package mx.edu.utng.staterjassi2;

import android.graphics.Canvas;

/**
 * Created by qas on 5/09/16.
 */
public abstract class BotonCambio {
    public abstract void oprimirEncendido(Modo modo, Canvas canvas);
}
