package mx.edu.utng.staterjassi2;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;

/**
 * Created by qas on 5/09/16.
 */
public class Bandera extends BotonCambio {

    @Override
    public void oprimirEncendido(Modo modo, Canvas canvas) {
        modo.setEstado(new Poste());
        Paint paint = new Paint();
        paint.setStyle(Paint.Style.FILL);
        float mitadX = canvas.getWidth()/2;
        float mitadY = canvas.getHeight()/2;
        paint.setColor(Color.GRAY);
        canvas.drawRect(mitadX*0.9f,mitadY*0.7f,mitadX*1f, mitadY*3f, paint);
        paint.setColor(Color.GREEN);
        canvas.drawRect(mitadX*0.6f,mitadY*0.5f,mitadX*1f, mitadY*1f, paint);
    }
}
