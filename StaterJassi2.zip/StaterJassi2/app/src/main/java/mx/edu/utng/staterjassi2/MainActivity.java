package mx.edu.utng.staterjassi2;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ImageButton;
import android.widget.LinearLayout;

public class MainActivity extends AppCompatActivity {

    private ImageButton btnEncender;
    private Modo modo;
    private Bandera estadoInicial;
    private LinearLayout layPrincipal;
    private Pantalla pantalla;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btnEncender = (ImageButton)findViewById(R.id.btn_encendido);
        layPrincipal = (LinearLayout)findViewById(R.id.lay_principal);
        estadoInicial = new Bandera();
        modo = new Modo(estadoInicial);
        pantalla = new Pantalla(MainActivity.this,
                estadoInicial, modo);
        layPrincipal.addView(pantalla);

        btnEncender.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                System.out.println(pantalla.toString());
                System.out.println(modo.toString());
                System.out.println(modo.getEstado().toString());
                pantalla.setEstado(modo.getEstado());
                modo.oprimirBoton();
                pantalla.invalidate();
            }
        });
    }
}