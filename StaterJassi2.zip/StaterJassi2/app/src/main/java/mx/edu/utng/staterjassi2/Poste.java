package mx.edu.utng.staterjassi2;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;

/**
 * Created by qas on 5/09/16.
 */
public class Poste extends BotonCambio {

    @Override
    public void oprimirEncendido(Modo modo, Canvas canvas) {
        modo.setEstado(new Bandera());
        Paint paint = new Paint();
        paint.setStyle(Paint.Style.FILL);
        float mitadX = canvas.getWidth()/2;
        float mitadY = canvas.getHeight()/2;
        paint.setColor(Color.WHITE);
        canvas.drawRect(mitadX * 2.55f, mitadY * 0.55f,
                mitadX * 1.45f, mitadY * 1.45f, paint);
        paint.setColor(Color.GRAY);
        canvas.drawRect(mitadX*0.9f,mitadY*0.7f,mitadX*1f, mitadY*3f, paint);

    }
}
