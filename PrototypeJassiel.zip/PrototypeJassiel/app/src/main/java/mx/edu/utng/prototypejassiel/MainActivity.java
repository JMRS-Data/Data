package mx.edu.utng.prototypejassiel;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private EditText edtNombre;
    private EditText edtIp;
    private EditText edtSub;
    private Button btnClonar;
    private GridView grvDirecciones;
    private ArrayList<Direcciones> direcciones;
    private Direcciones pc;
    private DireccionAdapter adapter;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        edtNombre = (EditText) findViewById(R.id.edt_nombre);
        edtIp = (EditText) findViewById(R.id.edt_ip);
        edtSub = (EditText) findViewById(R.id.edt_Sub);

        btnClonar = (Button)findViewById(R.id.btn_clonar);
        grvDirecciones = (GridView)findViewById(R.id.grv_documentos);
        direcciones = new ArrayList<Direcciones>();
        pc = new Direcciones();

        btnClonar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pc.setNombre(edtNombre.getText().toString());
                pc.setIp(edtIp.getText().toString());
                pc.setSub(edtSub.getText().toString());

                Direcciones clon = (Direcciones)pc.clonar();

                direcciones.add(clon);

                adapter = new DireccionAdapter(
                        MainActivity.this, direcciones);
                grvDirecciones.setAdapter(adapter);
            }
        });
    }
}
