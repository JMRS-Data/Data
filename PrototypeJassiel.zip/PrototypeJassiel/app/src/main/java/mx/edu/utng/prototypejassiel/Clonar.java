package mx.edu.utng.prototypejassiel;

/**
 * Created by qas on 2/09/16.
 */
public interface Clonar {
    Clonar clonar();
}
