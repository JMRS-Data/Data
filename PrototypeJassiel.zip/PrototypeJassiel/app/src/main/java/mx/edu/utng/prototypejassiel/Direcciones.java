package mx.edu.utng.prototypejassiel;

/**
 * Created by qas on 2/09/16.
 */
public class Direcciones implements Clonar {
    private String nombre;
    private String ip;
    private String sub;

    public Direcciones(){
        this.nombre = "";
        this.ip = "0.0.0.0";
        this.sub = "0.0.0.0";
    }

    public Direcciones(String nombre, String ip, String sub) {
        this.nombre = nombre;
        this.ip = ip;
        this.sub = sub;
    }

    @Override
    public Clonar clonar() {
        Direcciones clon = new Direcciones(nombre, ip, sub);
        return clon;
    }


    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getIp() {
        return ip;
    }

    public void setIp(String ip) {
        this.ip = ip;
    }

    public String getSub() {
        return sub;
    }

    public void setSub(String sub) {
        this.sub = sub;
    }
}
