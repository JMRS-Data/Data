package mx.edu.utng.prototypejassiel;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * Created by qas on 2/09/16.
 */
public class DireccionAdapter extends ArrayAdapter<Direcciones>{

    public DireccionAdapter(Context context, ArrayList<Direcciones> direcciones){
        super(context, 0, direcciones);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        Direcciones direcciones = getItem(position);
        if(convertView==null){
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.direccion_layout, parent, false);
        }
        TextView txvDireccion = (TextView)convertView.findViewById(R.id.txv_direccion);
        txvDireccion.setText(direcciones.getNombre()+""+direcciones.getSub()+ " - "+direcciones.getIp());

        return convertView;
    }
}
